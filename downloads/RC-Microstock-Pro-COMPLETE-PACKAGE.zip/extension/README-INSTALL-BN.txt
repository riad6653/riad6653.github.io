==========================================================
 RC Microstock Research Pro — Chrome Extension Install Guide
 (বাংলা) — By Riad Chowdhury
==========================================================
১) এই ZIP ফাইলটি ডাউনলোড করে Extract (Unzip) করুন।
২) Chrome / Edge / Brave ব্রাউজার খুলে ঠিকানায় লিখুন:  chrome://extensions
৩) ডান উপরের কোণায় "Developer mode" সুইচ ON করুন।
৪) বাম উপরে "Load unpacked" বাটনে ক্লিক করে এই Extract করা
   ফোল্ডারটি সিলেক্ট করুন।
৫) ব্যস! Toolbar-এ RC Stock Pro আইকন চলে আসবে।

সমস্যা হলে WhatsApp: +880 1618-674044 (Riad Chowdhury)
সাপোর্ট সাইট: https://riad-chowdhury-pro.netlify.app/
