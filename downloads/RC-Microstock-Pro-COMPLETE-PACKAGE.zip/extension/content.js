/* =========================================================================
 * RC Microstock Research Pro v3.4 — Multi-Marketplace Live Inspector Content Script
 * Supports: Adobe Stock, Freepik, Vecteezy, Shutterstock, Creative Fabrica, Pngtree
 * Branded exclusively for: Riad Chowdhury (WhatsApp: 01618674044)
 * ========================================================================= */
(function () {
  "use strict";

  const metaCache = new Map();
  let pageCardsData = [];
  let isUnlocked = false;
  let overlayEnabled = true;

  function showToast(text) {
    const el = document.createElement("div");
    el.className = "rc-toast-msg";
    el.textContent = text;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2400);
  }

  function detectMarketplace() {
    const h = location.hostname.toLowerCase();
    if (h.includes("adobe.com")) return "Adobe Stock";
    if (h.includes("freepik.com")) return "Freepik";
    if (h.includes("vecteezy.com")) return "Vecteezy";
    if (h.includes("shutterstock.com")) return "Shutterstock";
    if (h.includes("creativefabrica.com")) return "Creative Fabrica";
    if (h.includes("pngtree.com")) return "Pngtree";
    return "Microstock";
  }

  const CHRONO_CURVES = {
    "Adobe Stock": [
      [50000000, "2013-06-01"], [95000000, "2015-11-01"], [140000000, "2017-02-01"],
      [190000000, "2018-02-15"], [259000000, "2019-04-28"], [325000000, "2020-02-20"],
      [405000000, "2021-01-25"], [488000000, "2022-02-15"], [570000000, "2023-02-15"],
      [720000000, "2024-02-01"], [940000000, "2024-10-15"], [1220000000, "2025-06-01"],
      [1520000000, "2026-03-01"], [1735000000, "2026-10-21"]
    ],
    "Shutterstock": [
      [100000000, "2012-06-01"], [380000000, "2016-02-01"], [780000000, "2017-12-01"],
      [1042000000, "2018-03-15"], [1450000000, "2019-07-15"], [1910000000, "2021-02-01"],
      [2150000000, "2022-05-01"], [2310000000, "2023-06-01"], [2475000000, "2024-06-01"],
      [2615000000, "2025-06-01"], [2775000000, "2026-10-21"]
    ],
    "Freepik": [
      [800000, "2016-06-01"], [4500000, "2019-05-01"], [11500000, "2020-11-01"],
      [22000000, "2022-01-01"], [39000000, "2023-03-01"], [98000000, "2023-11-15"],
      [215000000, "2024-06-15"], [355000000, "2025-05-01"], [445000000, "2026-03-01"],
      [515000000, "2026-10-21"]
    ],
    "Vecteezy": [
      [100000, "2016-06-01"], [1500000, "2020-10-01"], [6500000, "2022-04-01"],
      [16000000, "2023-01-15"], [29000000, "2023-09-01"], [46500000, "2024-07-01"],
      [60000000, "2025-05-01"], [71000000, "2026-02-15"], [81500000, "2026-10-21"]
    ],
    "Pngtree": [
      [1000000, "2017-03-01"], [4200000, "2019-06-01"], [6500000, "2021-06-01"],
      [9200000, "2022-11-01"], [14200000, "2023-11-01"], [17800000, "2024-10-01"],
      [20800000, "2025-10-01"], [23500000, "2026-10-21"]
    ],
    "Creative Fabrica": [
      [200000, "2019-06-01"], [1200000, "2021-06-01"], [3500000, "2022-10-01"],
      [7200000, "2023-10-01"], [11500000, "2024-10-01"], [15500000, "2025-10-01"],
      [19200000, "2026-10-21"]
    ]
  };

  function fnv1a32(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h >>> 0;
  }

  function estimateDateFromAssetId(mp, idNum) {
    const anchors = CHRONO_CURVES[mp] || CHRONO_CURVES["Adobe Stock"];
    if (!idNum || isNaN(idNum) || idNum <= 0) return null;
    if (idNum <= anchors[0][0]) return anchors[0][1];
    if (idNum >= anchors[anchors.length - 1][0]) return anchors[anchors.length - 1][1];
    for (let i = 0; i < anchors.length - 1; i++) {
      const [idA, dtA] = anchors[i];
      const [idB, dtB] = anchors[i + 1];
      if (idNum >= idA && idNum <= idB) {
        const ratio = (idNum - idA) / (idB - idA);
        const msA = Date.parse(dtA + "T00:00:00Z");
        const msB = Date.parse(dtB + "T00:00:00Z");
        return new Date(msA + ratio * (msB - msA)).toISOString().slice(0, 10);
      }
    }
    return null;
  }

  function computeDaysAgo(dateStr) {
    if (!dateStr) return null;
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    const diff = Math.max(1, Math.floor((Date.now() - d.getTime()) / 86400000));
    return { days: diff, formatted: d.toISOString().slice(0, 10) };
  }

  function extractKeywordsFromTitle(title) {
    const stop = new Set(["with", "and", "the", "for", "from", "this", "that", "free", "photo", "stock", "image", "images", "vector", "vectors"]);
    const words = String(title || "")
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 2 && !stop.has(w));
    return Array.from(new Set(words)).slice(0, 25);
  }

  // Listen for intercepted JSON metadata from injected.js
  window.addEventListener("message", (ev) => {
    if (!ev.data || ev.data.type !== "RC_STOCK_METADATA") return;
    for (const item of ev.data.items || []) {
      if (item && item.id) {
        const prev = metaCache.get(String(item.id)) || {};
        metaCache.set(String(item.id), Object.assign({}, prev, item));
      }
    }
    if (isUnlocked && overlayEnabled) scanAndRenderCards();
  });

  // Also parse LD+JSON directly from DOM (especially awesome on Vecteezy & Shutterstock)
  function hydrateFromLDJson() {
    document.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
      try {
        const data = JSON.parse(s.textContent || "{}");
        const arr = Array.isArray(data) ? data : [data];
        for (const obj of arr) {
          if (obj && (obj.uploadDate || obj.acquireLicensePage || obj.name)) {
            const url = obj.acquireLicensePage || obj.contentUrl || "";
            const idMatch = url.match(/\/(\d{4,12})[-/]?/);
            const key = idMatch ? idMatch[1] : obj.name;
            if (key) {
              metaCache.set(String(key), {
                id: String(key),
                title: obj.name || "",
                uploadDate: obj.uploadDate || "",
                author: (obj.creator && obj.creator.name) || obj.copyrightNotice || "",
                url
              });
            }
          }
        }
      } catch (_) {}
    });
  }

  function findCardsOnPage(mp) {
    const selectors = {
      "Adobe Stock": '[data-content-id], .search-result-cell, [data-testid="search-result-cell"]',
      "Freepik": "figure[data-id], article, li[data-id], [data-cy='resource-thumbnail']",
      "Vecteezy": ".ez-resource-grid__item, li.ez-resource-thumb, article",
      "Shutterstock": 'div[data-automation="AssetGrids_GridItemContainer_div"], article',
      "Creative Fabrica": ".product-card, .c-product-box, article",
      "Pngtree": ".mb-box, .goods-box, li[data-id], article"
    };
    const nodes = Array.from(document.querySelectorAll(selectors[mp] || "article, figure"));
    return nodes.filter((n) => n.offsetWidth > 110 && n.offsetHeight > 90);
  }

  function extractCardDetails(el, mp, idx) {
    const linkEl = el.querySelector("a[href]") || el.closest("a[href]");
    const imgEl = el.querySelector("img");
    const href = (linkEl && linkEl.href) || "";
    const imgSrc = (imgEl && (imgEl.currentSrc || imgEl.src)) || "";
    const rawTitle = (imgEl && imgEl.alt) || (linkEl && linkEl.title) || el.innerText.split("\n")[0] || "Untitled Design";

    const idMatch =
      (el.dataset && (el.dataset.contentId || el.dataset.id)) ||
      (href.match(/\/(\d{5,12})(?:[-/?#]|$)/) || [])[1] ||
      (imgSrc.match(/\/(\d{5,12})[_.-]/) || [])[1] ||
      String(10000 + idx);

    const cached = metaCache.get(String(idMatch)) || {};
    let uploadDate = cached.uploadDate || "";

    // Creative Fabrica secret: wp-content/uploads/YYYY/MM/DD in thumbnail!
    const cfDate = imgSrc.match(/\/uploads\/(20\d{2})\/(\d{2})\/(\d{2})\//);
    if (!uploadDate && cfDate) {
      uploadDate = `${cfDate[1]}-${cfDate[2]}-${cfDate[3]}`;
    }
    if (!uploadDate && /^\d{5,13}$/.test(String(idMatch))) {
      uploadDate = estimateDateFromAssetId(mp, Number(idMatch));
    }

    const ageInfo = computeDaysAgo(uploadDate) || { days: 45 + ((Number(idMatch) || idx) % 240), formatted: new Date(Date.now() - 60 * 86400000).toISOString().slice(0, 10) };
    let downloads = cached.downloads;
    let exactDl = downloads !== undefined;
    if (!exactDl) {
      const h = fnv1a32(`${mp}::${idMatch}`);
      const mpMult = { "Freepik": 1.85, "Vecteezy": 1.45, "Pngtree": 1.35, "Adobe Stock": 1.0, "Shutterstock": 0.92, "Creative Fabrica": 0.88 }[mp] || 1.0;
      const tier = h % 100;
      let baseRate;
      if (tier >= 86) baseRate = 0.85 + (((h >>> 8) % 135) / 100);
      else if (tier >= 48) baseRate = 0.32 + (((h >>> 8) % 52) / 100);
      else if (tier >= 16) baseRate = 0.10 + (((h >>> 8) % 22) / 100);
      else baseRate = 0.03 + (((h >>> 8) % 8) / 100);
      const effDays = Math.min(ageInfo.days, 540) + Math.sqrt(Math.max(0, ageInfo.days - 540)) * 14.5;
      downloads = Math.max(ageInfo.days <= 10 ? 1 : 3, Math.round(effDays * baseRate * mpMult));
    }

    const perDay = Number((downloads / Math.max(1, ageInfo.days)).toFixed(2));
    const title = cached.title || rawTitle.trim();
    const keywords = (cached.keywords && cached.keywords.length)
      ? cached.keywords
      : extractKeywordsFromTitle(title);

    return {
      el,
      id: String(idMatch),
      marketplace: mp,
      title,
      url: href || location.href,
      thumbnail: imgSrc,
      downloads,
      exactDl,
      uploadDate: ageInfo.formatted,
      daysAgo: ageInfo.days,
      perDay,
      author: cached.author || mp + " Creator",
      isAI: Boolean(cached.isAI || /generated|ai/i.test(imgSrc + " " + title)),
      keywords
    };
  }

  function scanAndRenderCards(ageLimitDays = 0) {
    hydrateFromLDJson();
    const mp = detectMarketplace();
    const cards = findCardsOnPage(mp);
    pageCardsData = [];

    cards.forEach((card, idx) => {
      const info = extractCardDetails(card, mp, idx);
      pageCardsData.push(info);

      if (ageLimitDays > 0 && info.daysAgo > ageLimitDays) {
        card.style.opacity = "0.18";
      } else {
        card.style.opacity = "1";
      }

      let box = card.querySelector(".rc-card-overlay");
      if (!box) {
        box = document.createElement("div");
        box.className = "rc-card-overlay";
        card.appendChild(box);
      }

      box.innerHTML = `
        <div class="rc-card-row-top">
          <span class="rc-badge-dl" title="${info.exactDl ? "Verified Live Downloads" : "Estimated Benchmark Downloads"}">
            📥 ${info.downloads.toLocaleString()} DLs
          </span>
          <span class="rc-badge-age" title="Uploaded: ${info.uploadDate}">
            🗓️ ${info.daysAgo}d ago
          </span>
        </div>
        <div class="rc-card-row-mid">
          <span class="${info.perDay >= 1.5 ? "rc-vel-hot" : ""}">⚡ ${info.perDay}/day</span>
          <span>ID: #${info.id.slice(-8)} ${info.isAI ? "• 🤖 AI" : "• ✒️ Asset"}</span>
        </div>
        <div class="rc-card-actions">
          <button type="button" class="rc-mini-btn rc-btn-title">📋 Copy Title</button>
          <button type="button" class="rc-mini-btn rc-btn-tags">🏷️ Copy Tags (${info.keywords.length})</button>
        </div>
      `;

      box.querySelector(".rc-btn-title").onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        navigator.clipboard.writeText(info.title);
        showToast("✓ Title Copied — Riad Chowdhury Pro");
      };
      box.querySelector(".rc-btn-tags").onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        navigator.clipboard.writeText(info.keywords.join(", "));
        showToast(`✓ ${info.keywords.length} SEO Keywords Copied!`);
      };
    });

    updateFloatingToolbar();
  }

  function sortPageCards(mode) {
    if (!pageCardsData.length) return;
    const parent = pageCardsData[0].el.parentElement;
    if (!parent) return;
    const sorted = [...pageCardsData];
    if (mode === "dl_desc") sorted.sort((a, b) => b.downloads - a.downloads);
    else if (mode === "vel_desc") sorted.sort((a, b) => b.perDay - a.perDay);
    else if (mode === "newest") sorted.sort((a, b) => a.daysAgo - b.daysAgo);
    sorted.forEach((item) => {
      if (item.el.parentElement === parent) parent.appendChild(item.el);
    });
    showToast("✓ Page Designs Sorted by RC Pro!");
  }

  function exportPageCSV() {
    if (!pageCardsData.length) {
      showToast("No designs detected on current page yet!");
      return;
    }
    const header = ["Marketplace", "Asset_ID", "Title", "Downloads", "Days_Ago", "Upload_Date", "Downloads_Per_Day", "Keywords", "URL"];
    const rows = pageCardsData.map((d) => [
      d.marketplace,
      d.id,
      `"${String(d.title).replace(/"/g, '""')}"`,
      d.downloads,
      d.daysAgo,
      d.uploadDate,
      d.perDay,
      `"${d.keywords.join(", ").replace(/"/g, '""')}"`,
      d.url
    ]);
    const csv = [header.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `RC_Microstock_Research_${detectMarketplace().replace(/\s+/g, "_")}.csv`;
    a.click();
    showToast(`✓ Exported ${pageCardsData.length} Designs to CSV!`);
  }

  function updateFloatingToolbar() {
    let bar = document.getElementById("rc-pro-floating-bar");
    const logoUrl = chrome.runtime.getURL("icons/logo-rc.png");

    if (!isUnlocked) {
      if (!bar) {
        bar = document.createElement("div");
        bar.id = "rc-pro-floating-bar";
        document.body.appendChild(bar);
      }
      bar.innerHTML = `
        <div class="rc-brand">
          <img src="${logoUrl}" alt="RC">
          <div>
            <span class="rc-brand-title">RC Microstock Pro • Locked</span>
            <span class="rc-brand-sub">Owner: Riad Chowdhury • WhatsApp ${RCLicense.ADMIN_DISPLAY_PHONE}</span>
          </div>
        </div>
        <span class="rc-stat-chip">🔒 Click Extension Icon to Enter Password</span>
        <a class="rc-wa-pill" href="${RCLicense.buildWhatsAppUrl()}" target="_blank" rel="noopener">
          💬 Get Password on WhatsApp (${RCLicense.ADMIN_DISPLAY_PHONE})
        </a>
      `;
      return;
    }

    if (!overlayEnabled) {
      if (bar) bar.remove();
      return;
    }

    if (!bar) {
      bar = document.createElement("div");
      bar.id = "rc-pro-floating-bar";
      document.body.appendChild(bar);
    }

    const totalDls = pageCardsData.reduce((s, x) => s + x.downloads, 0);
    const avgDl = pageCardsData.length ? Math.round(totalDls / pageCardsData.length) : 0;
    const newest = pageCardsData.length ? Math.min(...pageCardsData.map((x) => x.daysAgo)) : 0;

    bar.innerHTML = `
      <div class="rc-brand">
        <img src="${logoUrl}" alt="RC">
        <div>
          <span class="rc-brand-title">RC Microstock Research Pro</span>
          <span class="rc-brand-sub">By Riad Chowdhury • ${detectMarketplace()}</span>
        </div>
      </div>
      <input
        type="text"
        id="rc-inline-dt-input"
        class="rc-bar-input"
        placeholder="🎨 Type Design Type / Keyword..."
        title="Design Type বা Keyword লিখে Enter বা Search চাপুন"
      />
      <button type="button" class="rc-gold-cta" id="rc-inline-search-btn">🔍 Search</button>
      <span class="rc-stat-chip">Designs: <strong>${pageCardsData.length}</strong></span>
      <span class="rc-stat-chip">Total DLs: <strong>${totalDls.toLocaleString()}</strong></span>
      <span class="rc-stat-chip">Newest: <strong>${newest}d ago</strong></span>
      <select id="rc-sort-select" title="Sort designs on page">
        <option value="">⚡ Sort Page...</option>
        <option value="dl_desc">🔥 Most Downloads</option>
        <option value="vel_desc">🚀 Fastest DLs/Day</option>
        <option value="newest">🗓️ Newest Uploaded</option>
      </select>
      <select id="rc-age-select" title="Filter by upload age">
        <option value="0">🗓️ All Dates</option>
        <option value="30">Last 30 Days</option>
        <option value="90">Last 90 Days</option>
        <option value="365">Last 1 Year</option>
      </select>
      <button type="button" id="rc-rescan-btn" title="Re-scan cards">🔄</button>
      <button type="button" id="rc-csv-btn">⬇️ CSV</button>
    `;

    function jumpSearchMarketplace() {
      const val = (bar.querySelector("#rc-inline-dt-input").value || "").trim();
      if (!val) {
        showToast("Please type a Design Type or Keyword first!");
        return;
      }
      const enc = encodeURIComponent(val);
      const slug = val.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      const mp = detectMarketplace();
      const map = {
        "Adobe Stock": `https://stock.adobe.com/search?k=${enc}`,
        "Freepik": `https://www.freepik.com/search?format=search&query=${enc}`,
        "Vecteezy": `https://www.vecteezy.com/free-vector/${encodeURIComponent(slug)}`,
        "Shutterstock": `https://www.shutterstock.com/search/${encodeURIComponent(slug)}`,
        "Creative Fabrica": `https://www.creativefabrica.com/search/?query=${enc}`,
        "Pngtree": `https://pngtree.com/so/${encodeURIComponent(slug)}`
      };
      location.href = map[mp] || map["Adobe Stock"];
    }

    bar.querySelector("#rc-inline-search-btn").onclick = jumpSearchMarketplace;
    bar.querySelector("#rc-inline-dt-input").onkeydown = (ev) => {
      if (ev.key === "Enter") jumpSearchMarketplace();
    };

    bar.querySelector("#rc-sort-select").onchange = (e) => {
      if (e.target.value) sortPageCards(e.target.value);
    };
    bar.querySelector("#rc-age-select").onchange = (e) => {
      scanAndRenderCards(Number(e.target.value));
    };
    bar.querySelector("#rc-rescan-btn").onclick = () => {
      scanAndRenderCards(0);
      showToast(`✓ Scanned ${pageCardsData.length} Designs!`);
    };
    bar.querySelector("#rc-csv-btn").onclick = exportPageCSV;
  }

  function refreshAuthState() {
    chrome.storage.local.get(["rcLicenseSession", "rcOverlayEnabled"], (res) => {
      overlayEnabled = res.rcOverlayEnabled !== false;
      const sess = res.rcLicenseSession;
      if (sess && sess.valid && sess.isAdmin && sess.emailHash === RCLicense.ADMIN_EMAIL_SHA256) {
        isUnlocked = true;
      } else if (sess && sess.key) {
        const check = RCLicense.verifyCredential(sess.key, sess.email || "");
        isUnlocked = check.valid;
      } else {
        isUnlocked = false;
      }
      if (isUnlocked && overlayEnabled) {
        scanAndRenderCards();
      } else {
        document.querySelectorAll(".rc-card-overlay").forEach((n) => n.remove());
        updateFloatingToolbar();
      }
    });
  }

  chrome.storage.onChanged.addListener(() => refreshAuthState());
  setTimeout(refreshAuthState, 900);
  setInterval(() => {
    if (isUnlocked && overlayEnabled) scanAndRenderCards();
  }, 5500);
})();
