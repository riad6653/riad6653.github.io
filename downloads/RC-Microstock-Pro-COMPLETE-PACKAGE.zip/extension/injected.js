/* =========================================================================
 * RC Microstock Research Pro — Page Context Interceptor (MAIN World)
 * Captures live JSON metadata (downloads, upload dates, keywords, authors)
 * directly from Adobe Stock, Freepik, Vecteezy, Shutterstock & Creative Fabrica
 * ========================================================================= */
(function () {
  "use strict";

  const seenAssets = new Map();

  function postAssets(source, items) {
    if (!items || !items.length) return;
    window.postMessage({ type: "RC_STOCK_METADATA", source, items }, "*");
  }

  function deepExtractAssets(obj, depth = 0) {
    if (!obj || typeof obj !== "object" || depth > 7) return;
    if (Array.isArray(obj)) {
      for (const el of obj) deepExtractAssets(el, depth + 1);
      return;
    }

    // Adobe Stock item signatures
    const id = obj.id || obj.content_id || obj.asset_id;
    const hasAdobe = (obj.nb_downloads !== undefined || obj.creation_date || obj.content_url || obj.thumbnail_url);
    if (id && hasAdobe) {
      const cid = String(id);
      const existing = seenAssets.get(cid) || {};
      const merged = {
        id: cid,
        title: obj.title || existing.title || "",
        downloads: obj.nb_downloads !== undefined ? Number(obj.nb_downloads) : existing.downloads,
        uploadDate: obj.creation_date || obj.upload_date || existing.uploadDate || "",
        author: obj.creator_name || (obj.author && (obj.author.name || obj.author)) || existing.author || "",
        keywords: Array.isArray(obj.keywords)
          ? obj.keywords.map((k) => (typeof k === "string" ? k : k && k.name)).filter(Boolean)
          : existing.keywords || [],
        isAI: Boolean(obj.is_gentech || obj.ai_generated || existing.isAI),
        category: (obj.category && obj.category.name) || obj.content_type || existing.category || "",
        premium: Boolean(obj.premium_level_id || obj.is_premium || existing.premium)
      };
      seenAssets.set(cid, merged);
    }

    // Freepik / Shutterstock / Generic item signatures
    if (id && (obj.downloads !== undefined || obj.likes !== undefined || obj.published_at || obj.dates)) {
      const cid = String(id);
      if (!seenAssets.has(cid)) {
        seenAssets.set(cid, {
          id: cid,
          title: obj.title || obj.name || obj.description || "",
          downloads: obj.downloads !== undefined ? Number(obj.downloads) : undefined,
          likes: obj.likes !== undefined ? Number(obj.likes) : undefined,
          uploadDate: obj.published_at || (obj.dates && obj.dates.published) || obj.created_at || "",
          author: (obj.author && (obj.author.name || obj.author.username)) || "",
          keywords: Array.isArray(obj.tags)
            ? obj.tags.map((t) => (typeof t === "string" ? t : t && (t.name || t.slug))).filter(Boolean)
            : [],
          isAI: Boolean(obj.ai || obj.is_ai || obj.generated),
          premium: Boolean(obj.premium || obj.is_premium)
        });
      }
    }

    for (const k of Object.keys(obj)) {
      if (k === "parent" || k === "window" || k === "document") continue;
      deepExtractAssets(obj[k], depth + 1);
    }
  }

  function flushSeen(tag) {
    if (seenAssets.size > 0) {
      postAssets(tag, Array.from(seenAssets.values()));
    }
  }

  // Hook fetch
  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = async function (...args) {
      const res = await origFetch.apply(this, args);
      try {
        const ct = (res.headers && res.headers.get("content-type")) || "";
        if (ct.includes("json")) {
          res.clone().json().then((data) => {
            deepExtractAssets(data);
            flushSeen("fetch");
          }).catch(() => {});
        }
      } catch (_) {}
      return res;
    };
  }

  // Hook XMLHttpRequest
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function () {
    this.addEventListener("load", function () {
      try {
        const ct = this.getResponseHeader("content-type") || "";
        if (ct.includes("json") && this.responseText) {
          deepExtractAssets(JSON.parse(this.responseText));
          flushSeen("xhr");
        }
      } catch (_) {}
    });
    return origOpen.apply(this, arguments);
  };

  // Scan initial window globals once DOM loads
  window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
      try {
        const candidates = [
          window.__INITIAL_STATE__,
          window.__NEXT_DATA__,
          window.__PRELOADED_STATE__,
          window.__NUXT__
        ];
        for (const c of candidates) {
          if (c) deepExtractAssets(c);
        }
        // Also parse embedded script JSON blocks on Adobe Stock / Vecteezy / Shutterstock
        document.querySelectorAll("script:not([src])").forEach((s) => {
          const txt = s.textContent || "";
          if (txt.includes("nb_downloads") || txt.includes('"@type":"ImageObject"') || txt.includes("creation_date")) {
            if (s.type === "application/ld+json") {
              try {
                deepExtractAssets(JSON.parse(txt));
              } catch (_) {}
            } else {
              // Fast regex extraction for Adobe Stock inline JSON objects
              const re = /"id"\s*:\s*(\d{5,12})[^{}]{0,600}?"nb_downloads"\s*:\s*(\d+)/g;
              let m;
              while ((m = re.exec(txt)) !== null) {
                const slice = txt.slice(Math.max(0, m.index - 200), Math.min(txt.length, m.index + 900));
                const dt = (slice.match(/"creation_date"\s*:\s*"([^"]+)"/) || [])[1] || "";
                const tt = (slice.match(/"title"\s*:\s*"([^"]+)"/) || [])[1] || "";
                const cr = (slice.match(/"creator_name"\s*:\s*"([^"]+)"/) || [])[1] || "";
                seenAssets.set(String(m[1]), {
                  id: String(m[1]),
                  downloads: Number(m[2]),
                  uploadDate: dt,
                  title: tt,
                  author: cr
                });
              }
            }
          }
        });
        flushSeen("dom-init");
      } catch (_) {}
    }, 600);
  });
})();
